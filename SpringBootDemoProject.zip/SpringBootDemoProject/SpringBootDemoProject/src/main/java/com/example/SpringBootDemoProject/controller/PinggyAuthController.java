package com.example.SpringBootDemoProject.controller;


import com.example.SpringBootDemoProject.service.PinggyAuthService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;


@RestController
public class PinggyAuthController {
    @Autowired
    private PinggyAuthService pinggyAuthService;

    /**
     * This method is responsible for check header value is present in request or not
     *
     * @return ResponseEntity<ResultResponse> returns header value
     */
    @GetMapping("/")
    public ResponseEntity<String> getAuthHeaderValue() {
        return ResponseEntity.ok(this.pinggyAuthService.getAuthHeaderValue());
    }
}
