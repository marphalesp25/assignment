package com.example.SpringBootDemoProject.service;

import jakarta.servlet.*;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import java.io.IOException;

@Component
@Order(1)
public class CustomAuthenticationFilter implements Filter {
    private static final ThreadLocal<String> AUTH_HEADER_VALUE = new ThreadLocal<>();

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain filterChain) throws IOException, ServletException {
        HttpServletRequest httpRequest = (HttpServletRequest) request;
        HttpServletResponse httpResponse = (HttpServletResponse) response;

        String authHeaderValue = httpRequest.getHeader("PinggyAuthHeader");
        if (authHeaderValue != null && !authHeaderValue.isEmpty()) {
            AUTH_HEADER_VALUE.set(authHeaderValue);
            filterChain.doFilter(request, response); //
        } else {
            httpResponse.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
            httpResponse.sendError(HttpServletResponse.SC_UNAUTHORIZED);
        }
    }

    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // Initialization logic, if any
    }

    @Override
    public void destroy() {
        // Cleanup logic, if any
    }

    public static String getAuthHeaderValue() {
        return AUTH_HEADER_VALUE.get();
    }
}
