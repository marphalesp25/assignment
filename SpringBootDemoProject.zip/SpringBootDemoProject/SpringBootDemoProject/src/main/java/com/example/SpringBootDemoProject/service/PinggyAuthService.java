package com.example.SpringBootDemoProject.service;


import org.springframework.stereotype.Service;


@Service
public class PinggyAuthService {

    public String getAuthHeaderValue() {
        String authHeaderValue = CustomAuthenticationFilter.getAuthHeaderValue();
        if (authHeaderValue != null) {
            return authHeaderValue;
        } else {
            return "PinggyAuthHeader not found";
        }
    }


}
